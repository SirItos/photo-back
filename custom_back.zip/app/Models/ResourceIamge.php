<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ResourceIamge extends Model
{
    
    protected $fillable = [
        'resource_id', 'path'
    ];
   
}
