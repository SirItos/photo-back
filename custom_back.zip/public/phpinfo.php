<?php
  phpinfo();